package edu.fra.uas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Datenvisualisierung {

	public static void main(String[] args) {
		SpringApplication.run(Datenvisualisierung.class, args);
	}

}
