package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.PieChartRepository;

//This class initializes the database with default values for pie chart if needed.

@Component
public class InitDBPieChart {

	@Autowired
	private PieChartRepository repository;

	@PostConstruct
	private void init() {

	}
}
