package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.Dashboard;
import edu.fra.uas.repository.DashboardRepository;

@RestController
@RequestMapping(value = "/api/dashboard") // Hier finden wir alle gegeben Dateien in der JSON
public class ApiControllerDashboard {

	@Autowired
	private DashboardRepository repository;

	// GET request to retrieve all dashboard charts data
	@GetMapping
	public ResponseEntity<List<Dashboard>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);

	}

	// POST request to save dashboard charts data
	@PostMapping()
	public ResponseEntity<String> saveBarchart(@RequestBody Dashboard dashboard) {
		this.repository.save(dashboard);
		return new ResponseEntity<>("Value is saved", HttpStatus.ACCEPTED);
	}

}
