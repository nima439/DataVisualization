package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.ScatterPointChart;
import edu.fra.uas.repository.ScatterPointChartRepository;

@RestController
@RequestMapping(value = "/api/scatterpointchart") // Hier finden wir alle gegeben Dateien in der JSON
public class ApiControllerScatterPointChart {

	@Autowired
	private ScatterPointChartRepository repository;

	// GET request to retrieve all Scatter point chart data
	@GetMapping
	public ResponseEntity<List<ScatterPointChart>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);

	}

	// POST request to save scatter point chart data
	@PostMapping()
	public ResponseEntity<String> saveBarchart(@RequestBody ScatterPointChart scatterpointchart) {
		this.repository.save(scatterpointchart);
		return new ResponseEntity<>("Barchart is saved", HttpStatus.ACCEPTED);
	}

}
