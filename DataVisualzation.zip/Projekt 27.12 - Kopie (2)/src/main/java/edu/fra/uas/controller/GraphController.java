package edu.fra.uas.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class GraphController {
	private static final Logger log = LoggerFactory.getLogger(GraphController.class);

	// These methods handle the HTTP GET requests for their designated URL path

	@RequestMapping("/dashboard")
	public String dashboard(Model model) {
		log.debug("/Dashboard --> start ");
		return "dashboard";
	}

	@RequestMapping("/barChart")
	public String barChart(Model model) {
		log.debug("/bar Chart --> start ");
		return "barChart";
	}

	@RequestMapping("/barChartName")
	public String barChartName(Model model) {
		log.debug("/barChartName--> start ");
		return "barChartName";
	}

	@RequestMapping("/pieChart")
	public String pieChart(Model model) {
		log.debug("/pieChart--> start ");
		return "pieChart";
	}

	@RequestMapping("/lineChart")
	public String lineChart(Model model) {
		log.debug("/Line Chart --> start ");
		return "lineChart";
	}

	@RequestMapping("/areaChart")
	public String areaChart(Model model) {
		log.debug("/area Chart --> start ");
		return "areaChart";
	}

	@RequestMapping("/scatterChart")
	public String scatterChart(Model model) {
		log.debug("/scatter Chart --> start ");
		return "scatterChart";
	}

	@RequestMapping("/table_form")
	public String table_form(Model model) {
		log.debug("/Table  --> start ");
		return "table_form";
	}

	@RequestMapping("/stockChart")
	public String stockChart(Model model) {
		log.debug("/stockChart  --> start ");
		return "stockChart";
	}

	@RequestMapping("/candlestickChart")
	public String candlestickChart(Model model) {
		log.debug("/candlestickChart  --> start ");
		return "candlestickChart";
	}

	@RequestMapping("/normalDistributionGraph")
	public String normalDistributionGraph(Model model) {
		log.debug("/normalDistributionGraph  --> start ");
		return "normalDistributionGraph";
	}
}