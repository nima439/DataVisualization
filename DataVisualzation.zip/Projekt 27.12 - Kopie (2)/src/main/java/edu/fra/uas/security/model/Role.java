package edu.fra.uas.security.model;

public enum Role {

	USER, ADMIN
	
}
